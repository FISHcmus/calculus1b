%% 
% Ngay 13 thang 11 2025
% p = 2a+ 5b - c
% MSSV: 25310023
p = 2*0 + 5 * 2 - 3; %% p = 7
fprintf("\n===\n")

 % p le, cau 12b,c/tr31
 % cau b y=1/(x+1), x =1, dx = -0.01
fprintf("Cau 12b, tinh vi phan cua  y=1/(x+1), x =1, dx = -0.01\n")
syms x;
f_b = 1/(x+1);
x_b = 1;
dx_b = -0.01;
diff_f_b= diff(f_b,x);
fprintf("Dao ham cua f la %s\n",diff_f_b)
fprintf("Vi phan cua f tai x = %f va dx= %f la %f\n",x_b,dx_b,subs(diff_f_b,x,x_b)*dx_b)
fprintf("\n===\n")
%% 12/c trang 13: y=tan(x) , x=pi/4, dx=-0.1
fprintf("Cau 12c trang 13, tinh vi phan cua y=tan(x) , x=pi/4, dx=-0.1\n")

f_c = tan(x);
x_c = pi/4;
dx_c = -0.1;
diff_f_c= diff(f_c,x);
fprintf("Dao ham cua f la %s\n",diff_f_c)
fprintf("Vi phan cua f tai x = %f va dx= %f la %f\n",x_c,dx_c,subs(diff_f_c,x,x_c)*dx_c)
fprintf("\n===\n")
