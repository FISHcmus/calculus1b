fprintf("Bai tap ngay 13 thang 11 nam 2025\n")
% MSSV: 25310023
% n = a+5*b+3*c 
n = 0 + 5*2 + 3*3; %% n = 19
fprintf("n = %d",n)
syms x h;
fprintf("\n====\n")
%% cau 15
f_15(x) = (x-1)/(x-2);
fprintf("tim dao ham cua %s\n",char(f_15))

fprintf("Cach 1: dung dinh nghia da(x) = limit((f_15(x+h) - f_15(x))/h,h,0);\n")
da(x) = limit((f_15(x+h) - f_15(x))/h,h,0);
fprintf("Dao ham cua f_15 la: %s\n", da(x));

fprintf("CAch 2: dung ham diff cua matlab\n")
db(x) = diff(f_15,x);
fprintf("Dao ham cua f_15 la: %s\n", db(x));

fprintf("So sanh da va db tai n = %d\n", n);

if da(n) == db(n)
    fprintf("Ket qua da(%d) = %f va db(%d) = %f giong nhau\n",n,da(n),n,db(n))
else
    fprintf("Ket qua da(%d) = %f va db(%d) = %f khong giong nhau\n",n,da(n),n,db(n))
end

fprintf("\n====\n")
%% cau 21: f = sqrt(3*x+1)

f_21(x) = sqrt(3*x+1);
fprintf("tim dao ham cua %s\n",char(f_21))

fprintf("Cach 1: dung dinh nghia  limit((f_21(x+h) - f_21(x))/h,h,0)\n")
da(x) = limit((f_21(x+h) - f_21(x))/h,h,0);
fprintf("Dao ham cua f_21 la: %s\n", da(x));

fprintf("CAch 2: dung ham diff cua matlab\n")
db(x) = diff(f_21,x);
fprintf("Dao ham cua f_21  la: %s\n", db(x));

fprintf("So sanh da va db tai n = %d\n", n);

if da(n) == db(n)
    fprintf("Ket qua da(%d) = %f va db(%d) = %f giong nhau\n",n,da(n),n,db(n))
else
    fprintf("Ket qua da(%d) = %f va db(%d) = %f khong giong nhau\n",n,da(n),n,db(n))
end

fprintf("\n====\n")
%% cau 23 f = 1/sqrt(x+2)

f_23(x) = 1/sqrt(x+2);
fprintf("tim dao ham cua %s\n",char(f_23))

fprintf("Cach 1: dung dinh nghia  limit((f_23(x+h) - f_23(x))/h,h,0)\n")
da(x) = limit((f_23(x+h) - f_23(x))/h,h,0);
fprintf("Dao ham cua f_23 la: %s\n", da(x));

fprintf("CAch 2: dung ham diff cua matlab\n")
db(x) = diff(f_23,x);
fprintf("Dao ham cua f_23 (Cach 2) la: %s\n", db(x));

fprintf("So sanh da va db tai n = %d\n", n);

if da(n) == db(n)
    fprintf("Ket qua da(%d) = %f va db(%d) = %f giong nhau\n",n,da(n),n,db(n))
else
    fprintf("Ket qua da(%d) = %f va db(%d) = %f khong giong nhau\n",n,da(n),n,db(n))
end

fprintf("\n====\n")