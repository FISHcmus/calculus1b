clear all;
clc

% MSSV: 25310023 
% ngay: 30/10/2023
a = 0; b= 2; c = 3;
m = a + 2*b +3*c;

% m = 13
%%
% 1c) 
disp('cau 1c trang 12')
syms x

f = sqrt(x)*(1+(sin((2*pi)/x))^2);

% giai theo dinh ly kep
disp('cach 1: giai theo dinh ly kep')
disp("Vi  -1 <= sin((2*pi)/x) <= 1 ")
disp("nen 0<= (sin((2*pi)/x))^2 <=1")
disp("nen sqrt(x) <= sqrt(x)*(1+(sin((2*pi)/x))^2) <= 2* sqrt(x)")
if limit(sqrt(x),x,0) == limit(2*sqrt(x),x,0)
    fprintf('gioi han ham so ben trai %d:\n',limit(sqrt(x),x,0))
    fprintf('gioi han ham so ben phai %d:\n', limit(2*sqrt(x), x, 0));
    disp('vi gioi han 2 ham so o 2 dau bang 0 khi x tien toi 0 nen theo dinh ly gioi han kep thi gioi han ham so = 0 khi x tien toi 0')
else
    disp('vi gioi han 2 dau khac nhau nen ta khong tim ra lim')
end

%% giai truc tiep bang matlab
disp('cach 2: giai truc tiep bang 1 dong lenh matlab  result = limit(f,x,0);')
result = limit(f,x,0);
display(result)

%% 9c)
disp('cau 9c trang 14')
g = piecewise(x < 1, 1-x^2, ...
    x >=1, 1/x);

% diem can xet
a = 1;

l_right = limit(g,x,a,'right');
l_left = limit(g,x,a,'left');

fprintf('gioi han ben phai la %d\ngioi han ben trai la %d\n',l_right,l_left)

if l_right == l_left
    disp(' vi gioi han tien tu ben trai bang gioi han tien tu ben phai, ham so lien tuc')
else
    disp('vi gioi han tien tu trai khong bang gioi han tien tu phai, ham so khong lien tuc')
end
%%
%9e
disp('cau 9e trang 14')
g2= piecewise(x<0,cos(x), ...
    x == 0, 0, ...
    x > 0,1-x^2);
a = 0 ;

l_right = limit(g2,x,a,'right');
l_left = limit(g2,x,a,'left');
fprintf('gioi han ben phai la %d\ngioi han ben trai la %d\n',l_right,l_left)

if l_right == l_left
    disp(' vi gioi han tien tu ben trai bang gioi han tien tu ben phai, ham so lien tuc')
else
    disp('vi gioi han tien tu trai khong bang gioi han tien tu phai, ham so khong lien tuc')
end

%% cau 10b

disp('cau 10b trang 14')

h = piecewise(x<=1, x+1, ...
    (x>1) & (x<3)  , 1/x, ...
    x>=3, sqrt(x-3));

giatritai1 = subs(h,x,1); % subs ham thay bien x bang gia tri 1 trong ham h
giatritai3 = subs(h,x,3);
limit_tai_1_ben_trai = limit(h,x,1,'left');
limit_tai_1_ben_phai = limit(h,x,1,'right');
limit_tai_3_ben_trai = limit(h,x,3,'left');
limit_tai_3_ben_phai = limit(h,x,3,'right');

fprintf('gioi han tai 1 ben trai la %d\ngioi han tai 1 ben phai la %d\n',limit_tai_1_ben_trai,limit_tai_1_ben_phai)
fprintf('gioi han tai 3 ben trai la %f\ngioi han tai 3 ben phai la %d\n',limit_tai_3_ben_trai,limit_tai_3_ben_phai)


disp('xet tinh gian doan cua h tai  diem x= 1')
if limit_tai_1_ben_phai == limit_tai_1_ben_trai
    disp('vi gioi han tai 1 ben trai = ben phai nen ham so lien tuc tai 1')
else
    disp('vi gioi han tai 1 ben trai khong bang ben phai ham so gian doan tai 1')
    disp('xet tinh lien tuc ben trai tai 1')
    if limit_tai_1_ben_trai == giatritai1
        disp('vi gioi han ben trai tai 1 bang gia tri cua h tai 1 nen lien tuc ben trai tai 1')
    else
        disp('vi gioi han ben trai tai 1 khong bang gia tri cua ham tai 1 nen ham so khong lien tuc ben trai tai 1')
    end
    if limit_tai_1_ben_phai == giatritai1
        disp('vi gioi han ben phai tai 1 bang gia tri cua h tai 1 nen lien tuc ben phai tai 1')
    else
        disp('vi gioi han ben phai tai 1 khong bang gia tri ham tai 1 nen ham so khong lien tuc ben phai tai 1')
    end
    
end


disp('xet tinh gian doan cua h tai  diem x= 3')
if limit_tai_3_ben_phai == limit_tai_3_ben_trai
    disp('vi gioi han tai 3 ben trai = ben phai nen ham so lien tuc tai 3')
else
    disp('vi gioi han tai 3 ben trai khong bang ben phai ham so gian doan tai 3')
    disp('xet tinh lien tuc ben trai tai 3')
    if limit_tai_3_ben_trai == giatritai3
        disp('vi gioi han ben trai tai 3 bang gia tri cua h tai 3 nen lien tuc ben trai tai 3')
    else
        disp('vi gioi han ben trai tai 3 khong bang gia tri cua ham tai 3 nen ham so khong lien tuc ben trai tai 3')
    end
    if limit_tai_3_ben_phai == giatritai3
        disp('vi gioi han ben phai tai 3 bang gia tri cua h tai 3 nen lien tuc ben phai tai 3')
    else
        disp('vi gioi han ben phai tai 3 khong bang gia tri cua ham tai 3 nen ham so khong lien tuc ben trai tai 3')
    end
end